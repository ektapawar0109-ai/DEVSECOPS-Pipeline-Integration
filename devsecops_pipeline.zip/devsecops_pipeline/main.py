import os
import re
from datetime import datetime


SECURITY_ISSUES = []


# -------------------------
# STATIC CODE SCAN
# -------------------------

def scan_code():

    print("\nRunning Static Code Scan...")

    with open(
        "sample_code.py",
        "r"
    ) as file:

        code = file.read()

    if "eval(" in code:

        SECURITY_ISSUES.append(
            "Dangerous use of eval()"
        )

    if re.search(
        r'password\s*=',
        code,
        re.IGNORECASE
    ):

        SECURITY_ISSUES.append(
            "Hardcoded password found"
        )

    print("Static Scan Complete")


# -------------------------
# SECRET SCAN
# -------------------------

def scan_secrets():

    print("\nRunning Secret Scan...")

    with open(
        "sample_code.py",
        "r"
    ) as file:

        code = file.read()

    if "API_KEY" in code:

        SECURITY_ISSUES.append(
            "API Key exposed"
        )

    print("Secret Scan Complete")


# -------------------------
# DEPENDENCY SCAN
# -------------------------

def dependency_scan():

    print(
        "\nRunning Dependency Scan..."
    )

    with open(
        "requirements.txt",
        "r"
    ) as file:

        deps = file.readlines()

    vulnerable = [
        "flask==1.0.0",
        "django==2.0.0"
    ]

    for dep in deps:

        dep = dep.strip()

        if dep in vulnerable:

            SECURITY_ISSUES.append(
                f"Vulnerable dependency: {dep}"
            )

    print(
        "Dependency Scan Complete"
    )


# -------------------------
# REPORT
# -------------------------

def generate_report():

    if not os.path.exists(
        "reports"
    ):
        os.makedirs(
            "reports"
        )

    filename = (
        f"reports/security_report.txt"
    )

    with open(
        filename,
        "w"
    ) as report:

        report.write(
            "DEVSECOPS SECURITY REPORT\n"
        )

        report.write(
            "=" * 50 + "\n"
        )

        report.write(
            f"\nGenerated: {datetime.now()}\n\n"
        )

        if SECURITY_ISSUES:

            report.write(
                "ISSUES FOUND:\n\n"
            )

            for issue in SECURITY_ISSUES:

                report.write(
                    f"- {issue}\n"
                )

        else:

            report.write(
                "No issues found\n"
            )

    print(
        f"\nReport saved: {filename}"
    )


# -------------------------
# DEPLOYMENT DECISION
# -------------------------

def deployment_status():

    print("\n")

    if SECURITY_ISSUES:

        print(
            "DEPLOYMENT BLOCKED"
        )

        print(
            "\nSecurity Issues:"
        )

        for issue in SECURITY_ISSUES:

            print("-", issue)

    else:

        print(
            "SAFE TO DEPLOY"
        )


# -------------------------
# PIPELINE
# -------------------------

def run_pipeline():

    SECURITY_ISSUES.clear()

    print(
        "\nStarting DevSecOps Pipeline..."
    )

    scan_code()

    scan_secrets()

    dependency_scan()

    generate_report()

    deployment_status()


# -------------------------
# MENU
# -------------------------

def menu():

    while True:

        print("\n")
        print("=" * 40)
        print("DEVSECOPS PIPELINE")
        print("=" * 40)

        print("1. Run Pipeline")
        print("2. Exit")

        choice = input(
            "\nEnter Choice: "
        )

        if choice == "1":

            run_pipeline()

        elif choice == "2":

            break

        else:

            print(
                "Invalid choice"
            )


if __name__ == "__main__":

    menu()