password = "admin123"

API_KEY = "123456789"

def calculate(data):

    return eval(data)